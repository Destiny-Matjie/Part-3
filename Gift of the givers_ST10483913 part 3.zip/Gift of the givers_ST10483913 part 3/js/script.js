document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // 1. INTERACTIVE ELEMENTS - ACCORDION
    function initAccordion() {
        const accordions = document.querySelectorAll('.accordion');
        accordions.forEach(accordion => {
            const headers = accordion.querySelectorAll('.accordion-header');
            headers.forEach(header => {
                header.addEventListener('click', function() {
                    const content = this.nextElementSibling;
                    const isActive = content.classList.contains('active');
                    
                    // Close all siblings
                    const parent = this.parentElement;
                    const siblings = parent.querySelectorAll('.accordion-content');
                    siblings.forEach(sib => {
                        sib.classList.remove('active');
                        sib.style.maxHeight = '0';
                    });
                    siblings.forEach(sib => {
                        const sibHeader = sib.previousElementSibling;
                        if (sibHeader) sibHeader.classList.remove('active');
                    });
                    
                    // Toggle current
                    if (!isActive) {
                        content.classList.add('active');
                        content.style.maxHeight = content.scrollHeight + 'px';
                        this.classList.add('active');
                    }
                });
            });
        });
    }

    // 2. INTERACTIVE ELEMENTS - TABS
    function initTabs() {
        const tabsContainers = document.querySelectorAll('.tabs-container');
        tabsContainers.forEach(container => {
            const tabs = container.querySelectorAll('.tab-btn');
            const contents = container.querySelectorAll('.tab-content');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const target = this.dataset.tab;
                    
                    // Remove active from all
                    tabs.forEach(t => t.classList.remove('active'));
                    contents.forEach(c => c.classList.remove('active'));
                    
                    // Add active to current
                    this.classList.add('active');
                    const targetContent = container.querySelector(`#${target}`);
                    if (targetContent) {
                        targetContent.classList.add('active');
                    }
                });
            });
        });
    }

    // 3. INTERACTIVE ELEMENTS - MODAL
    function initModals() {
        const modalTriggers = document.querySelectorAll('[data-modal-trigger]');
        const modalClose = document.querySelectorAll('.modal-close, .modal-overlay');
        
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                const modalId = this.dataset.modalTrigger;
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        });
        
        modalClose.forEach(close => {
            close.addEventListener('click', function() {
                const modal = this.closest('.modal-overlay, .modal');
                if (modal) {
                    modal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
        
        // Close modal on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const activeModal = document.querySelector('.modal.active');
                if (activeModal) {
                    activeModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            }
        });
    }


    // 4. GALLERY WITH LIGHTBOX 
function initGallery() {
    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightboxImg');
    const lightboxCaption = document.getElementById('lightboxCaption');
    
    if (!lightbox) return;
    
    galleryItems.forEach(item => {
        item.addEventListener('click', function(e) {
            // Get image source and caption from data attributes
            const imgSrc = this.dataset.image || this.querySelector('img')?.src || '';
            const caption = this.dataset.caption || this.querySelector('.gallery-overlay')?.textContent || 'Gift of the Givers';
            
            if (lightboxImg && imgSrc) {
                lightboxImg.src = imgSrc;
                lightboxImg.alt = caption;
            }
            if (lightboxCaption) {
                lightboxCaption.textContent = caption;
            }
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });
    
    // Close lightbox
    const lightboxClose = document.querySelector('.lightbox-close');
    const lightboxOverlay = document.querySelector('.lightbox-overlay');
    
    const closeLightboxFn = function() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
        // Optionally clear src
        if (lightboxImg) lightboxImg.src = '';
    };
    
    if (lightboxClose) lightboxClose.addEventListener('click', closeLightboxFn);
    if (lightboxOverlay) lightboxOverlay.addEventListener('click', closeLightboxFn);
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const active = document.querySelector('.lightbox.active');
            if (active) {
                active.classList.remove('active');
                document.body.style.overflow = '';
                if (lightboxImg) lightboxImg.src = '';
            }
        }
    });
}

    // 5. DYNAMIC CONTENT LOADING
    function initDynamicContent() {
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        const contentContainer = document.getElementById('dynamicContent');
        
        if (loadMoreBtn && contentContainer) {
            const items = [
                { title: 'Türkiye Earthquake Response', desc: 'Deployed search and rescue teams within 24 hours of the devastating earthquake.' },
                { title: 'Ukraine Humanitarian Aid', desc: 'Delivered 200+ tonnes of medical supplies and food to conflict zones.' },
                { title: 'Pakistan Flood Relief', desc: 'Provided emergency shelter and clean water to 50,000+ affected families.' },
                { title: 'Gaza Emergency Response', desc: 'Medical teams on the ground providing critical care in conflict zones.' }
            ];
            
            let currentIndex = 0;
            const itemsPerLoad = 2;
            
            // Function to load more
            function loadMore() {
                const fragment = document.createDocumentFragment();
                const end = Math.min(currentIndex + itemsPerLoad, items.length);
                
                for (let i = currentIndex; i < end; i++) {
                    const div = document.createElement('div');
                    div.className = 'dynamic-item';
                    div.innerHTML = `
                        <h4>${items[i].title}</h4>
                        <p>${items[i].desc}</p>
                    `;
                    fragment.appendChild(div);
                }
                
                contentContainer.appendChild(fragment);
                currentIndex = end;
                
                if (currentIndex >= items.length) {
                    loadMoreBtn.style.display = 'none';
                }
            }
            
            // Attach event listener
            loadMoreBtn.addEventListener('click', loadMore);
            
            // Load initial items
            loadMore();
        }
    }

    // 6. SEARCH FUNCTIONALITY (FIXED)
    function initSearch() {
        const searchInput = document.getElementById('searchInput');
        const searchResults = document.getElementById('searchResults');
        const searchData = document.getElementById('searchData');
        
        if (searchInput && searchResults) {
            let data = [];
            
            if (searchData) {
                try {
                    data = JSON.parse(searchData.textContent);
                } catch(e) {
                    data = [
                        { title: 'Disaster Relief', url: '#', desc: 'Emergency response to natural disasters' },
                        { title: 'Water & Sanitation', url: '#', desc: 'Clean water projects across Africa' },
                        { title: 'Medical Aid', url: '#', desc: 'Healthcare services in underserved areas' }
                    ];
                }
            }
            
            searchInput.addEventListener('input', function() {
                const query = this.value.toLowerCase().trim();
                searchResults.innerHTML = ''; // FIXED: was 'results'
                
                if (query.length < 2) {
                    searchResults.classList.remove('active');
                    return;
                }
                
                const filtered = data.filter(item => {
                    return item.title.toLowerCase().includes(query) ||
                           item.desc.toLowerCase().includes(query);
                });
                
                if (filtered.length > 0) {
                    searchResults.classList.add('active');
                    filtered.forEach(item => {
                        const resultItem = document.createElement('a');
                        resultItem.href = item.url;
                        resultItem.className = 'search-result-item';
                        resultItem.innerHTML = `
                            <strong>${item.title}</strong>
                            <span>${item.desc}</span>
                        `;
                        searchResults.appendChild(resultItem);
                    });
                } else {
                    searchResults.classList.add('active');
                    const noResult = document.createElement('div');
                    noResult.className = 'search-no-result';
                    noResult.textContent = 'No results found';
                    searchResults.appendChild(noResult);
                }
            });
            
            // Close search results on outside click
            document.addEventListener('click', function(e) {
                if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                    searchResults.classList.remove('active');
                }
            });
        }
    }

    // 7. ANIMATIONS (Intersection Observer)
    function initAnimations() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animated');
                    }
                });
            }, { threshold: 0.1 });
            
            elements.forEach(el => observer.observe(el));
        } else {
            // Fallback for older browsers
            elements.forEach(el => el.classList.add('animated'));
        }
    }

    // 8. MOBILE MENU
    function initMobileMenu() {
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.querySelector('.nav-links');
        
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function() {
                navLinks.classList.toggle('active');
                const expanded = navLinks.classList.contains('active');
                this.setAttribute('aria-expanded', expanded);
            });
        }
    }

    // 9. SMOOTH SCROLL
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === '#') return;
                
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    // 10. INTERACTIVE MAPS (Leaflet - placeholder)
    function initInteractiveMaps() {
        const mapContainers = document.querySelectorAll('.interactive-map');
        
        if (typeof L !== 'undefined' && mapContainers.length > 0) {
            mapContainers.forEach(container => {
                const lat = parseFloat(container.dataset.lat) || -29.6167;
                const lng = parseFloat(container.dataset.lng) || 30.3769;
                const zoom = parseInt(container.dataset.zoom) || 13;
                
                const map = L.map(container.id).setView([lat, lng], zoom);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 18,
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);
                
                L.marker([lat, lng])
                    .addTo(map)
                    .bindPopup(container.dataset.popup || 'Gift of the Givers Office');
            });
        }
    }

    // INITIALIZE ALL COMPONENTS
    initAccordion();
    initTabs();
    initModals();
    initGallery();
    initDynamicContent();
    initSearch();
    initAnimations();
    initMobileMenu();
    initSmoothScroll();
    initInteractiveMaps();

    console.log('Gift of the Givers - All components initialized');
});

// ==========================================
// GLOBAL FUNCTIONS (for inline onclick)
// ==========================================

// Modal functions
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Lightbox functions (for inline onclick on gallery items)
function openLightbox(emoji, caption) {
    const lightbox = document.getElementById('lightbox');
    const display = document.getElementById('lightboxDisplay');
    const captionEl = document.getElementById('lightboxCaption');
    if (lightbox && display) {
        display.textContent = emoji || '🌍';
        if (captionEl) captionEl.textContent = caption || 'Gift of the Givers';
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// ==========================================
// FORM FUNCTIONS (Enhanced with AJAX)
// ==========================================

// Contact Form with AJAX
function submitContactForm(event) {
    event.preventDefault();
    
    const form = document.getElementById('contactForm');
    const successBanner = document.getElementById('cSuccessBanner');
    
    // Validate form
    if (!validateContactForm()) {
        return false;
    }
    
    // Collect form data
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Show loading state
    const submitBtn = form.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    
    // Simulate AJAX submission
    setTimeout(function() {
        // Build email content
        const emailBody = `
            Name: ${data.cname}
            Email: ${data.cemail}
            Subject: ${data.csubject}
            Message: ${data.cmsg}
        `;
        
        // Simulate sending email
        console.log('Email sent:', {
            to: 'info@giftofthegivers.org',
            from: data.cemail,
            subject: `Contact Form: ${data.csubject}`,
            body: emailBody
        });
        
        // Show success
        form.style.display = 'none';
        if (successBanner) successBanner.style.display = 'block';
        
        // Reset button
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
    }, 1500);
    
    return false;
}

// Enquiry Form with AJAX
function submitEnquiryForm(event) {
    event.preventDefault();
    
    const form = document.getElementById('enquiryForm');
    const successBanner = document.getElementById('successBanner');
    
    // Validate form
    if (!validateEnquiryForm()) {
        return false;
    }
    
    // Collect form data
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Get selected skills
    const skills = [];
    document.querySelectorAll('input[name="skills"]:checked').forEach(checkbox => {
        skills.push(checkbox.value);
    });
    data.skills = skills.join(', ');
    
    // Show loading state
    const submitBtn = form.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Submitting...';
    submitBtn.disabled = true;
    
    // Simulate AJAX submission
    setTimeout(function() {
        // Build enquiry response
        const response = generateEnquiryResponse(data);
        
        // Show success
        form.style.display = 'none';
        if (successBanner) {
            successBanner.style.display = 'block';
            // Add additional info to success banner
            const responseDiv = document.createElement('div');
            responseDiv.className = 'enquiry-response';
            responseDiv.innerHTML = response;
            successBanner.appendChild(responseDiv);
        }
        
        // Reset button
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        console.log('Enquiry submitted:', data);
        
    }, 1500);
    
    return false;
}

function generateEnquiryResponse(data) {
    let response = '<p><strong>Thank you for your enquiry!</strong></p>';
    
    if (data.enqtype === 'volunteer') {
        response += `<p>Based on your availability (${data.avail}) and skills, we will contact you about volunteer opportunities.</p>`;
        response += `<p>Please check your email (${data.email}) for further instructions.</p>`;
    } else if (data.enqtype === 'sponsor') {
        response += `<p>Thank you for your interest in sponsoring our programs. A corporate partnerships representative will contact you within 2 business days.</p>`;
    } else if (data.enqtype === 'donation') {
        response += `<p>We appreciate your interest in donating. Please visit our secure donation portal at: <a href="#">Donation Link</a></p>`;
    } else {
        response += `<p>We have received your enquiry and will respond within 2 business days.</p>`;
    }
    
    response += `<p><small>Reference: ${Date.now().toString(36).toUpperCase()}</small></p>`;
    return response;
}

// ==========================================
// VALIDATION FUNCTIONS
// ==========================================

function validateContactForm() {
    let valid = true;
    
    function check(fieldId, groupId, testFn) {
        const field = document.getElementById(fieldId);
        const group = document.getElementById(groupId);
        if (!testFn(field.value)) {
            group.classList.add('error');
            valid = false;
        } else {
            group.classList.remove('error');
        }
    }
    
    check('cname', 'grp-cname', v => v.trim().length >= 2);
    check('cemail', 'grp-cemail', v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));
    check('csubject', 'grp-csubject', v => v !== '');
    check('cmsg', 'grp-cmsg', v => v.trim().length >= 10);
    
    if (!valid) {
        const firstError = document.querySelector('.form-group.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    return valid;
}

function validateEnquiryForm() {
    let valid = true;
    
    function check(fieldId, groupId, testFn) {
        const field = document.getElementById(fieldId);
        const group = document.getElementById(groupId);
        if (!testFn(field.value)) {
            group.classList.add('error');
            valid = false;
        } else {
            group.classList.remove('error');
        }
    }
    
    check('fname', 'grp-fname', v => v.trim().length >= 2);
    check('lname', 'grp-lname', v => v.trim().length >= 2);
    check('email', 'grp-email', v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));
    check('phone', 'grp-phone', v => v.replace(/\D/g,'').length >= 7);
    check('enqtype', 'grp-type', v => v !== '');
    check('avail', 'grp-avail', v => v !== '');
    check('msg', 'grp-msg', v => v.trim().length >= 10);
    
    if (!valid) {
        const firstError = document.querySelector('.form-group.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    return valid;
}